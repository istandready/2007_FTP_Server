#ifndef __COM_H__
#define __COM_H__

#include <stdio.h>
#include <errno.h>

/*---- DEFINE DECLARATION ----------------------------------------------------*/
#define     OK       0
#define     NG      -1

#endif

